<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/home.css">
    <link rel="stylesheet" href="/css/profile.css">
    <link rel="stylesheet" href="/css/login.css">
    <title>TOKEM | Update Profile</title>
</head>
<body>
    <?php echo e(View::make('layout.header')); ?>

    <div class="heads"></div>

    <div class="contents-1-container profile">
        <div class="contents-1-atas">
            <h1 class="bawah">Update Account</h1>
        </div>
    </div>

    <div class="contents-2-container">
        <div class="contents-2-box">
            <form action="/account/update/<?php echo e($data->name); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="profile-container">
                    <legend>Name</legend>
                    <input type="text" name="name" id="name" value="<?php echo e($data->name); ?>">
                    <?php if($errors->has('name')): ?>
                    <div class="errors">
                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="profile-container update">
                    <legend>Email</legend>
                    <p><?php echo e($data->email); ?></p>
                </div>
                <div class="profile-container">
                    <legend>Phone Number</legend>
                    <input type="text" name="phone" id="phone" value="<?php echo e($data->phone); ?>">
                    <?php if($errors->has('phone')): ?>
                    <div class="errors">
                        <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="profile-container">
                    <legend>Address</legend>
                    <textarea name="address"style="resize:none" id="address" rows="10" rows="10"><?php echo e($data->address); ?></textarea>
                    <?php if($errors->has('address')): ?>
                    <div class="errors">
                        <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="profile-container">
                    <legend>Old Password</legend>
                    <input type="password" name="password" id="password">
                    <?php if($errors->has('password')): ?>
                    <div class="errors">
                        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
                <h3>Only Enter New Password if You Wish to Change It</h3>
                <div class="profile-container">
                    <legend>New Password</legend>
                    <input type="password" name="new password" id="password">
                    <?php if($errors->has('new_password')): ?>
                    <div class="errors">
                        <span class="text-danger"><?php echo e($errors->first('new_password')); ?></span>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="profile-container">
                    <legend>Confirmation Password</legend>
                    <input type="password" name="confirmation password" id="password">
                    <?php if($errors->has('confirmation_password')): ?>
                    <div class="errors">
                        <span class="text-danger"><?php echo e($errors->first('confirmation_password')); ?></span>
                    </div>
                    <?php endif; ?>

                </div>
                <div class="buttons-container update">
                    
                    <button type="submit">Update Profile</button>
                    <a href="/account">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    <?php echo e(View::make('layout.footer')); ?>

</body>
</html>

<?php /**PATH /home/rhenaldariendra/Documents/Webprogramming/Dapa/Project_Lab/resources/views/updateProfile.blade.php ENDPATH**/ ?>