<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/add.css">
    <link rel="stylesheet" href="/css/login.css">
    <title>TOKEM | Add Product</title>
</head>

<body>
    <?php echo e(View::make('layout.header')); ?>

    <?php
    $category = App\Models\categories::all();
    ?>
    <div class="contents-container">
        <h1>Add Product</h1>
        <form action="/add/product/" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Photo</p>
                </div>
                <div class="rights image">
                    <input type="file" name="image" id="image">
                    <?php if($errors->has('image')): ?>
                    <div class="errors">
                        <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Name</p>
                </div>
                <div class="rights">
                    <input type="text" value="<?php echo e(old('name')); ?>" name="name" id="name">
                    <?php if($errors->has('name')): ?>
                    <div class="errors">
                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Price</p>
                </div>
                <div class="rights">
                    <input type="text" name="price" value="<?php echo e(old('price')); ?>"id="price">
                    <?php if($errors->has('price')): ?>
                    <div class="errors">
                        <span class="text-danger"><?php echo e($errors->first('price')); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Stock</p>
                </div>
                <div class="rights">
                    <input type="number" name="stock"value="<?php echo e(old('stock')); ?>" id="stock">
                    <?php if($errors->has('stock')): ?>
                    <div class="errors">
                        <span class="text-danger"><?php echo e($errors->first('stock')); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Description</p>
                </div>
                <div class="rights">
                    <textarea name="description" id="description" rows="15"><?php echo e(old('description')); ?></textarea>
                    <?php if($errors->has('description')): ?>
                    <div class="errors">
                        <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Category</p>
                </div>
                <div class="rights">

                    <select name="category" id="category">
                        <option value="">Choose a Category</option>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e(old('category') == $item->name ? "selected" : ""); ?> value="<?php echo e($item->name); ?>">
                            <?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('category')): ?>
                    <div class="errors">
                        <span class="text-danger"><?php echo e($errors->first('category')); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="buttons-container-add">
                <button type="submit">Save</button>
                <a href="/add">Cancel</a>
            </div>

        </form>
    </div>
    <script>
        var at =  document.getElementById("name");
    </script>
    <?php echo e(View::make('layout.footer')); ?>

</body>

</html>
<?php /**PATH /home/rhenaldariendra/Documents/Webprogramming/Dapa/Project_Lab/resources/views/admin/product.blade.php ENDPATH**/ ?>