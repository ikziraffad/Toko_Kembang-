<link rel="stylesheet" href="/css/main.css">
<div class="footers">
    <div class="foot-kiri">
        <p>© Copyright Tokem - Toko Kembang 2021</p>
    </div>
    <div class="foot-kanan">
        <a href="#"><i class="bi bi-instagram"></i></a>
        <a href="#"><i class="bi bi-twitter"></i></a>
    </div>
</div>

<?php /**PATH /home/rhenaldariendra/Documents/Webprogramming/Dapa/Project_Lab/resources/views/layout/footer.blade.php ENDPATH**/ ?>