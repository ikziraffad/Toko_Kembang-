<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/cart.css">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TOKEM | Cart Confirmation</title>
    <link rel="stylesheet" href="/css/login.css">
</head>
<body>
    <?php echo e(View::make('layout.header')); ?>

    <?php
        $total = 0;
    ?>
    <div class="contents-container">

        <h1>Please Confirm Your Order</h1>
        <div class="carts-box">
            <div class="tops">
                <div class="prod">
                    <p>PRODUCT</p>
                </div>
                <div class="price">
                    <p>PRICE</p>
                </div>
                <div class="qty">
                    <p>QUANTITY</p>
                </div>
                <div class="subtotal">
                    <p>SUBTOTAL</p>
                </div>
            </div>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bottoms">
                <div class="prod">
                    <img src="<?php echo e(Storage::url($item->product[0]->image)); ?>" alt="">
                    <p><?php echo e($item->product[0]->name); ?></p>
                </div>
                <div class="price">
                    <p>Rp. <?php echo e($item->product[0]->price); ?>,00</p>
                </div>
                <div class="qty">
                    <div class="inputs">
                        <p><?php echo e($item->quantity); ?></p>
                    </div>
                </div>
                <div class="subtotal">
                    <p>Rp. <?php echo e($item->quantity * $item->product[0]->price); ?>,00</p>
                    <?php
                        $total = $total + ($item->quantity * $item->product[0]->price);
                    ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <h3 style="padding-top: 20px;">Ships to : <?php echo e($data[0]->user->address); ?></h3>
        <div class="totals">
            <?php
                $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                $charactersLength = strlen($characters);
                $randomString = '';
                for ($i = 0; $i < 6; $i++) {
                    $randomString .= $characters[rand(0, $charactersLength - 1)];
                }
            ?>
            <h2>Grand Total : Rp. <?php echo e($total); ?>,00</h2>
            <form action="/cart/confirmation/submit">
                <p style="font-size: 19px;">Please Enter The Following Passcode to Checkout <?php echo e($randomString); ?></p>
                <input type="hidden" name="conf" value="<?php echo e($randomString); ?>">
                <input type="text" name="pass" id="pass" placeholder="XXXXXX">
                <?php if($errors->any()): ?>
                <div class="errors">
                    <span class="text-danger"><?php echo e($errors->first()); ?></span>
                </div>
                <?php endif; ?>
                <button type="submit" style="cursor: pointer; border-style: none;">Checkout</button>
            </form>
        </div>
    </div>
    <?php echo e(View::make('layout.footer')); ?>

</body>
</html>
<?php /**PATH /home/rhenaldariendra/Documents/Webprogramming/Dapa/Project_Lab/resources/views/user/cartConfirm.blade.php ENDPATH**/ ?>