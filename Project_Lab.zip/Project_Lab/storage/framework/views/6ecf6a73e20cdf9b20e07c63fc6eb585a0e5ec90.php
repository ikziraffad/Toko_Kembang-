<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/cart.css">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TOKEM | History Transaction</title>
    <link rel="stylesheet" href="/css/login.css">
</head>

<body>
    <?php echo e(View::make('layout.header')); ?>


    <div class="contents-container">
        <?php if($data->isEmpty()): ?>
        <h1>Your Don't Have Any Transaction</h1>
        <?php else: ?>
        <h1>Transaction History</h1>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2>Transaction Date : <?php echo e($item->created_at); ?></h2>
        <div class="carts-box history">
            <div class="tops">
                <div class="prod">
                    <p>PRODUCT</p>
                </div>
                <div class="price">
                    <p>PRICE</p>
                </div>
                <div class="qty">
                    <p>QUANTITY</p>
                </div>
                <div class="subtotal">
                    <p>SUBTOTAL</p>
                </div>
            </div>
            <?php $__currentLoopData = $item->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bottoms">
                <div class="prod">
                    <img src="<?php echo e(Storage::url($key->product[0]->image)); ?>" alt="">
                    <p><?php echo e($key->product[0]->name); ?></p>
                </div>
                <div class="price">
                    <p>Rp. <?php echo e($key->product[0]->price); ?>,00</p>
                </div>
                <div class="qty">
                    <p></p>
                </div>
                <div class="subtotal">
                    <p>Rp. <?php echo e($key->quantity * $key->product[0]->price); ?>,00</p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>
    </div>


    <?php echo e(View::make('layout.footer')); ?>

</body>

</html>
<?php /**PATH /home/rhenaldariendra/Documents/Webprogramming/Dapa/Project_Lab/resources/views/user/history.blade.php ENDPATH**/ ?>