<!DOCTYPE html>
<html lang="en" style="background-image:url(<?php echo e(Storage::url('Image/bg-login-regis.jpg')); ?>);">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/login.css">
    <title>TOKEM | Register</title>
</head>
<body>
    <div class="container">
        <div class="cont-1">
            <img src="<?php echo e(Storage::url('Image/logo.svg')); ?>" alt="">
            <a href="/login">Already Have an Account?</a>
        </div>

        <form action="<?php echo e(route('register-user')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            <div class="input-container">
                <p>Name</p>
                <input type="text" name="Name" id="name" placeholder="Name"  value="<?php echo e(old('Name')); ?>"autofocus>
                <?php if($errors->has('Name')): ?>
                <div class="errors">
                    <span class="text-danger"><?php echo e($errors->first('Name')); ?></span>
                </div>
                <?php endif; ?>
            </div>
            <div class="input-container">
                <p>Email</p>
                <input type="email" name="Email" id="email" placeholder="user@user.com" value="<?php echo e(old('Email')); ?>"autofocus>
                <?php if($errors->has('Email')): ?>
                <div class="errors">
                    <span class="text-danger"><?php echo e($errors->first('Email')); ?></span>
                </div>
                <?php endif; ?>
            </div>
            <div class="input-container">
                <p>Phone Number</p>
                <input type="text" name="Phone" id="phone" placeholder="081111222333" value = "<?php echo e(old('Phone')); ?>" >
                <?php if($errors->has('Phone')): ?>
                <div class="errors">
                    <span class="text-danger"><?php echo e($errors->first('Phone')); ?></span>
                </div>
                <?php endif; ?>
            </div>
            <div class="input-container">
                <p>Address</p>
                <textarea name="Address" style="resize:none" id="address" rows="10"><?php echo e(old('Address')); ?></textarea>
                <?php if($errors->has('Address')): ?>
                <div class="errors">
                    <span class="text-danger"><?php echo e($errors->first('Address')); ?></span>
                </div>
                <?php endif; ?>
            </div>
            <div class="input-container">
                <p>Password</p>
                <input type="password" name="Password" id="password" placeholder="Password" >
                <?php if($errors->has('Password')): ?>
                <div class="errors">
                    <span class="text-danger"><?php echo e($errors->first('Password')); ?></span>
                </div>
                <?php endif; ?>
            </div>

            <div class="input-container">
                <p>Confirm Password</p>
                <input type="password" name="Confirmation" id="confpassword" placeholder="Confirm Password" >
                <?php if($errors->has('Confirmation')): ?>
                <div class="errors">
                    <span class="text-danger"><?php echo e($errors->first('Confirmation')); ?></span>
                </div>
                <?php endif; ?>
            </div>
            <button>
                <input class="login-btn"type="submit" value="Sign Up" placeholder="Sign up">
            </button>

        </form>
    </div>

</body>
</html>
<?php /**PATH /home/rhenaldariendra/Documents/Webprogramming/Dapa/Project_Lab/resources/views/register.blade.php ENDPATH**/ ?>