<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/product.css">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <title>TOKEM | Product</title>
</head>

<body>
    <?php echo e(View::make('layout.header')); ?>


    <div class="contents-container">
        <div class="container-produk">
            <div class="top-part d-flex justify-content-between align-items-center">
                <h1>Our Product</h1>
                <form action="/product/search">
                    <input type="text" name="search" id="search">
                    <button type="submit">Search</button>
                </form>
            </div>
            <div class="bottom-part container mx-auto mt-5">
                <div class="row">
                    <?php if(!$data->isEmpty()): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <?php if(Auth::check()): ?>
                        <?php if(Auth::user()->role=='user' && $item->stock==0): ?>
                        <?php else: ?>
                        <div class="col-md-3 mb-3">
                            <div class="card" style="width: 18rem;">
                                <a href="/product/<?php echo e($item->id); ?>">
                                    <img src="<?php echo e(Storage::url($item->image)); ?>" class="card-img-top" alt="image product">
                                </a>
                                <div class="card-body">
                                    <a href="/product/<?php echo e($item->id); ?>" class="card-title text-dark"><?php echo e($item->name); ?></a>
                                    <h6 class="card-subtitle mb-2 text-muted">Rp. <?php echo e($item->price); ?>,00</h6>
                                    <p class="card-text"></p>
                                    <?php if(auth()->guard()->guest()): ?>
                                    <a href="/product/<?php echo e($item->id); ?>" class="btn mr-2 text-white">Add to Cart</a>
                                    <?php else: ?>
                                    <?php if(Auth::user()->role=="user"): ?>
                                    <a href="/product/<?php echo e($item->id); ?>" class="btn mr-2 text-white">Add to Cart</a>
                                    <?php else: ?>
                                    <?php if($item->stock==0): ?>
                                    <p class="text-danger">Product Unavailable</p>
                                    <?php endif; ?>
                                    <a href="/edit/<?php echo e($item->name); ?>/admin" class="btn mr-2 text-white"><i
                                            class="bi bi-pencil"></i> Edit</a>
                                    <a href="/delete/product/<?php echo e($item->id); ?>" class="btn mr-2 text-white"><i
                                            class="bi bi-trash"></i> Remove</a>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    <?php elseif($item->stock!=0): ?>
                    <div class="col-md-3 mb-3">
                        <div class="card" style="width: 18rem;">
                            <a href="/product/<?php echo e($item->id); ?>">
                                <img src="<?php echo e(Storage::url($item->image)); ?>" class="card-img-top" alt="image product">
                            </a>
                            <div class="card-body">
                                <a href="/product/<?php echo e($item->id); ?>" class="card-title text-dark"><?php echo e($item->name); ?></a>
                                <h6 class="card-subtitle mb-2 text-muted">Rp. <?php echo e($item->price); ?>,00</h6>
                                <p class="card-text"></p>
                                <a href="/product/<?php echo e($item->id); ?>" class="btn mr-2 text-white">Add to Cart</a>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>



                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <h1>No Product Match</h1>
                    <?php endif; ?>



                </div>
            </div>

        </div>
        <div class="links d-flex justify-content-center mt-3">
            <?php echo e($data->links()); ?>

        </div>
    </div>
    <?php echo e(View::make('layout.footer')); ?>

</body>

</html>
<?php /**PATH /home/rhenaldariendra/Documents/Webprogramming/Dapa/Project_Lab/resources/views/product.blade.php ENDPATH**/ ?>