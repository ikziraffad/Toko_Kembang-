<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/cart.css">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TOKEM | Cart</title>
    <link rel="stylesheet" href="/css/login.css">
</head>
<body>
    <?php echo e(View::make('layout.header')); ?>

    <?php
        $total = 0;
    ?>
    <div class="contents-container">
        <?php if($errors->any()): ?>
        <div class="errors">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="text-danger"><?php echo e($item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <?php if($data->isEmpty()): ?>
        <h1>Your Cart is Empty!</h1>
        <?php else: ?>
        <h1>Cart</h1>
        <div class="carts-box">
            <div class="tops">
                <div class="prod">
                    <p>PRODUCT</p>
                </div>
                <div class="price">
                    <p>PRICE</p>
                </div>
                <div class="qty">
                    <p>QUANTITY</p>
                </div>
                <div class="subtotal">
                    <p>SUBTOTAL</p>
                </div>
            </div>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bottoms">
                <div class="prod">
                    <img src="<?php echo e(Storage::url($item->product[0]->image)); ?>" alt="">
                    <p><?php echo e($item->product[0]->name); ?></p>
                </div>
                <div class="price">
                    <p>Rp. <?php echo e($item->product[0]->price); ?>,00</p>
                </div>
                <div class="qty">
                    <form action="/cart/update" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($item->product[0]->id); ?>">
                        <input type="number" value="<?php echo e($item->quantity); ?>" name="quantity" id="quantity">
                    </form>

                </div>
                <div class="subtotal">
                    <p>Rp. <?php echo e($item->quantity * $item->product[0]->price); ?>,00</p>
                    <?php
                        $total = $total + ($item->quantity * $item->product[0]->price);
                    ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="totals">
            <h2>Grand Total : Rp. <?php echo e($total); ?>,00</h2>
            <a href="/cart/confirmation">Checkout</a>
        </div>
        <?php endif; ?>
    </div>
    <?php echo e(View::make('layout.footer')); ?>

</body>
</html>
<?php /**PATH /home/rhenaldariendra/Documents/Webprogramming/Dapa/Project_Lab/resources/views/user/cart.blade.php ENDPATH**/ ?>