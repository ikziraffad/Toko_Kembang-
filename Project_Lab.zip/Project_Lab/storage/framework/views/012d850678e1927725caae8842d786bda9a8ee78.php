<link rel="stylesheet" href="/css/main.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
<nav class="navigation-bars">
    <div class="nav-lefts">
        <a class="logo" href="#">
            <img src="<?php echo e(Storage::url('Image/logo.svg')); ?>" alt="logo">
        </a>
    </div>

    <div class="nav-rights">
        <li class="navlist-items">
            <a href="/" class="item <?php echo e((request()->is('/'))||(request()->is('home')) ? 'active' : ''); ?>">Home</a>
        </li>
        <li class="navlist-items">
            <a href="/product" class="item <?php echo e((request()->is('product')) ? 'active' : ''); ?>">Product</a>
        </li>
        <li class="navlist-items">
            <a href="/aboutus" class="item <?php echo e((request()->is('aboutus')) ? 'active' : ''); ?>">About Us</a>
        </li>

        <?php if(auth()->guard()->guest()): ?>
        <li class="navlist-items">
            <a href="/login" class="item">Login</a>
        </li>
        <?php else: ?>
        <?php if(Auth::user()->role=='admin'): ?>
        <li class="navlist-items">
            <a href="/add" class="item <?php echo e((request()->is('add')) ? 'active' : ''); ?>">Admin Dashboard</a>
        </li>

        <?php else: ?>
        <li class="navlist-items">
            <a href="/cart" class="item <?php echo e((request()->is('cart')) ? 'active' : ''); ?>">Cart</a>
        </li>

        <?php endif; ?>
        <li class="navlist-items">
            <a href="/account" class="item <?php echo e((request()->is('account')) ? 'active' : ''); ?>">Account</a>
        </li>
        <li class="navlist-items">
            <a href="<?php echo e(route('logout-user')); ?>" class="item">Logout</a>
        </li>
        <?php endif; ?>
    </div>
</nav>
<?php /**PATH /home/rhenaldariendra/Documents/Webprogramming/Dapa/Project_Lab/resources/views/layout/header.blade.php ENDPATH**/ ?>