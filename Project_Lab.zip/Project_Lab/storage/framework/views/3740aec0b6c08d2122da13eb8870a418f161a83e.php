<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/add.css">
    <link rel="stylesheet" href="/css/login.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/aboutUs.css">
    <title>TOKEM | Add Category</title>
</head>
<body>
    <?php echo e(View::make('layout.header')); ?>

    <?php
    $category = App\Models\categories::all();
    ?>
    <div class="contents-container">
        <h1>Add Category</h1>
        <h3 class="mt-5">Available Categories</h3>
        <div class="row row-cols-4 align-items-center mt-1">
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col d-flex justify-content-md-center mb-4">
                <div class="leftss d-flex justify-content-center align-items-center">
                    <p><?php echo e($item->name[0]); ?></p>
                </div>
                <div class="rightss">
                    <p><?php echo e($item->name); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <form action="/add/category" method="post">
            <?php echo csrf_field(); ?>
            <div class="inputs-container mt-3" style="border-top: 1px solid black;">
                <div class="lefts">
                    <p>Category Name</p>
                </div>
                <div class="rights">
                    <input type="text" value="<?php echo e(old('category')); ?>" name="category" id="category">
                    <?php if($errors->has('category')): ?>
                    <div class="errors">
                        <span class="text-danger text-white"><?php echo e($errors->first('category')); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="buttons-container-category d-flex justify-content-end mt-3">
                <button type="submit" class="add-button">Add Category</button>
            </div>
        </form>
    </div>


    <?php echo e(View::make('layout.footer')); ?>

</body>
</html>
<?php /**PATH /home/rhenaldariendra/Documents/Webprogramming/Dapa/Project_Lab/resources/views/admin/category.blade.php ENDPATH**/ ?>