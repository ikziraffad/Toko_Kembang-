<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/add.css">
    <link rel="stylesheet" href="/css/login.css">
    <title>TOKEM | Edit Product</title>
</head>
<body>
    <?php echo e(View::make('layout.header')); ?>

    <?php
    $category = App\Models\categories::all();
    ?>
    <div class="contents-container">
        <h1><?php echo e($data->name); ?></h1>
        <form action="/edit/<?php echo e($data->id); ?>" method="POST" enctype="multipart/form-data">
            <?php echo e(method_field('put')); ?>

            <?php echo csrf_field(); ?>
            <div class="inputs-container">
                <div class="lefts" >
                    
                </div>
                <div class="rights">
                    <img src="<?php echo e(Storage::url($data->image)); ?>" alt="">
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Photo</p>
                </div>
                <div class="rights image">
                    <input type="file" name="image" id="image">
                    <?php if($errors->has('image')): ?>
                    <div class="errors">
                        <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Price</p>
                </div>
                <div class="rights">
                    <input type="text" name="price" value="<?php echo e($data->price); ?>"id="price">
                    <?php if($errors->has('price')): ?>
                    <div class="errors">
                        <span class="text-danger"><?php echo e($errors->first('price')); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Stock</p>
                </div>
                <div class="rights">
                    <input type="number" name="stock"value="<?php echo e($data->stock); ?>" id="stock">
                    <?php if($errors->has('stock')): ?>
                    <div class="errors">
                        <span class="text-danger"><?php echo e($errors->first('stock')); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Description</p>
                </div>
                <div class="rights">
                    <textarea name="description" id="description" rows="15"><?php echo e($data->description); ?></textarea>
                    <?php if($errors->has('description')): ?>
                    <div class="errors">
                        <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="buttons-container-add">
                <button type="submit">Save</button>
                <a href="/add">Cancel</a>
            </div>

        </form>
    </div>
    <script>
        var at =  document.getElementById("name");
    </script>
    <?php echo e(View::make('layout.footer')); ?>

</body>
</html>
<?php /**PATH /home/rhenaldariendra/Documents/Webprogramming/Dapa/Project_Lab/resources/views/admin/edit.blade.php ENDPATH**/ ?>