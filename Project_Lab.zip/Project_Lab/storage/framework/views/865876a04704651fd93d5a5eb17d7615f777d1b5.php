<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/detail.css">
    <link rel="stylesheet" href="/css/login.css">
    <title>TOKEM | Detail Product</title>
</head>
<body>
    <?php echo e(View::make('layout.header')); ?>

    <?php if($errors->any()&&!$errors->has('quantity')): ?>
    <script>
        alert("Item Already in Cart");
    </script>
    <?php endif; ?>
    <div class="contents-container">
        <div class="lefts">
            <img src="<?php echo e(Storage::url($data->image)); ?>" alt="">
        </div>
        <div class="middles">
            <h1><?php echo e($data->name); ?></h1>
            <p><?php echo e($data->description); ?></p>
            <p>Stock : <?php echo e($data->stock); ?></p>
            <p>Price : <?php echo e($data->price); ?></p>
            <p>Category : <?php echo e($data->category->name); ?></p>
        </div>

        <?php if(Auth::check()): ?>
        <?php if(Auth::user()->role == 'user'): ?>
        <div class="rights">
            <form action="/add/cart" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="product_id" value="<?php echo e($data->id); ?>">
                <input type="number" name="quantity" min="1" max="<?php echo e($data->stock); ?>" id="quantity">
                <?php if($errors->has('quantity')): ?>
                <div class="errors">
                    <span class="text-danger"><?php echo e($errors->first('quantity')); ?></span>
                </div>
                <?php endif; ?>
                <button type="submit">Add to Cart</button>
            </form>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>



    <?php echo e(View::make('layout.footer')); ?>

</body>
</html>

<?php /**PATH /home/rhenaldariendra/Documents/Webprogramming/Dapa/Project_Lab/resources/views/detail.blade.php ENDPATH**/ ?>