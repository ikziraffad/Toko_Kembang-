<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\ProductsController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/home', function(){
    return view('home');
});
Route::get('/', function () {
    return redirect('/home');
});

Route::get('/login', function(){
    return view('login');
});
Route::get('/register', function(){
    return view('register');
});
Route::get('/aboutus', function(){
    return view('aboutUs');
});

Route::post('/regis', [UserController::class, 'registration'])->name('register-user');
Route::post('/signin', [UserController::class, 'login'])->name('login-user');
Route::get('/logout', [UserController::class, 'logout'])->name('logout-user');
Route::get('/account', [UserController::class, 'getProfile']);
Route::get('/account/update', [UserController::class, 'getProfielUpdates']);
Route::post('/account/update/{name}', [UserController::class, 'updateProfile']);
Route::get('/add', [AdminController::class, 'index']);
Route::get('/add/{page}/admin', [AdminController::class, 'getAdd']);
Route::post('/add/product/', [AdminController::class, 'addProduct']);
Route::post('/add/category', [AdminController::class, 'addCategory']);

Route::get('/product/search', [ProductsController::class,'search']);
Route::get('/product', [UserController::class,'getProduct']);
Route::get('/delete/product/{id}', [AdminController::class,'deleteProduct']);

Route::get('/edit/{name}/admin', [AdminController::class,'getEditProduct']);
Route::put('/edit/{id}', [AdminController::class,'editProduct']);

Route::get('/product/{id}', [ProductsController::class, 'getDetail']);
Route::get('/cart', [UserController::class, 'getCart']);
Route::get('/cart/confirmation', [UserController::class, 'getCartConf']);
Route::get('/cart/confirmation/submit', [UserController::class, 'confirmPasscode']);

Route::get('/user/history', [UserController::class, 'getHistory']);

Route::post('/add/cart', [UserController::class, 'addToCart']);
Route::post('/cart/update', [UserController::class, 'updateCart']);
