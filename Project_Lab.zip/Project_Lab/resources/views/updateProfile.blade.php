<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/home.css">
    <link rel="stylesheet" href="/css/profile.css">
    <link rel="stylesheet" href="/css/login.css">
    <title>TOKEM | Update Profile</title>
</head>
<body>
    {{View::make('layout.header')}}
    <div class="heads"></div>

    <div class="contents-1-container profile">
        <div class="contents-1-atas">
            <h1 class="bawah">Update Account</h1>
        </div>
    </div>

    <div class="contents-2-container">
        <div class="contents-2-box">
            <form action="/account/update/{{$data->name}}" method="POST">
                @csrf
                <div class="profile-container">
                    <legend>Name</legend>
                    <input type="text" name="name" id="name" value="{{$data->name}}">
                    @if ($errors->has('name'))
                    <div class="errors">
                        <span class="text-danger">{{ $errors->first('name') }}</span>
                    </div>
                    @endif
                </div>
                <div class="profile-container update">
                    <legend>Email</legend>
                    <p>{{$data->email}}</p>
                </div>
                <div class="profile-container">
                    <legend>Phone Number</legend>
                    <input type="text" name="phone" id="phone" value="{{$data->phone}}">
                    @if ($errors->has('phone'))
                    <div class="errors">
                        <span class="text-danger">{{ $errors->first('phone') }}</span>
                    </div>
                    @endif
                </div>
                <div class="profile-container">
                    <legend>Address</legend>
                    <textarea name="address"style="resize:none" id="address" rows="10" rows="10">{{$data->address}}</textarea>
                    @if ($errors->has('address'))
                    <div class="errors">
                        <span class="text-danger">{{ $errors->first('address') }}</span>
                    </div>
                    @endif
                </div>
                <div class="profile-container">
                    <legend>Old Password</legend>
                    <input type="password" name="password" id="password">
                    @if ($errors->has('password'))
                    <div class="errors">
                        <span class="text-danger">{{ $errors->first('password') }}</span>
                    </div>
                    @endif
                </div>
                <h3>Only Enter New Password if You Wish to Change It</h3>
                <div class="profile-container">
                    <legend>New Password</legend>
                    <input type="password" name="new password" id="password">
                    @if ($errors->has('new_password'))
                    <div class="errors">
                        <span class="text-danger">{{ $errors->first('new_password') }}</span>
                    </div>
                    @endif
                </div>

                <div class="profile-container">
                    <legend>Confirmation Password</legend>
                    <input type="password" name="confirmation password" id="password">
                    @if ($errors->has('confirmation_password'))
                    <div class="errors">
                        <span class="text-danger">{{ $errors->first('confirmation_password') }}</span>
                    </div>
                    @endif

                </div>
                <div class="buttons-container update">
                    {{-- <a href="#">Update Profile</a> --}}
                    <button type="submit">Update Profile</button>
                    <a href="/account">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    {{View::make('layout.footer')}}
</body>
</html>

