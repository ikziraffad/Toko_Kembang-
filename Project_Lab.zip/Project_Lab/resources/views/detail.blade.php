<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/detail.css">
    <link rel="stylesheet" href="/css/login.css">
    <title>TOKEM | Detail Product</title>
</head>
<body>
    {{View::make('layout.header')}}
    @if ($errors->any()&&!$errors->has('quantity'))
    <script>
        alert("Item Already in Cart");
    </script>
    @endif
    <div class="contents-container">
        <div class="lefts">
            <img src="{{Storage::url($data->image)}}" alt="">
        </div>
        <div class="middles">
            <h1>{{$data->name}}</h1>
            <p>{{$data->description}}</p>
            <p>Stock : {{$data->stock}}</p>
            <p>Price : {{$data->price}}</p>
            <p>Category : {{$data->category->name}}</p>
        </div>

        @if (Auth::check())
        @if(Auth::user()->role == 'user')
        <div class="rights">
            <form action="/add/cart" method="post">
                @csrf
                <input type="hidden" name="product_id" value="{{$data->id}}">
                <input type="number" name="quantity" min="1" max="{{$data->stock}}" id="quantity">
                @if ($errors->has('quantity'))
                <div class="errors">
                    <span class="text-danger">{{ $errors->first('quantity') }}</span>
                </div>
                @endif
                <button type="submit">Add to Cart</button>
            </form>
        </div>
        @endif
        @endif
    </div>



    {{View::make('layout.footer')}}
</body>
</html>

