<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/add.css">
    <link rel="stylesheet" href="/css/login.css">
    <title>TOKEM | Edit Product</title>
</head>
<body>
    {{View::make('layout.header')}}
    @php
    $category = App\Models\categories::all();
    @endphp
    <div class="contents-container">
        <h1>{{$data->name}}</h1>
        <form action="/edit/{{$data->id}}" method="POST" enctype="multipart/form-data">
            {{method_field('put')}}
            @csrf
            <div class="inputs-container">
                <div class="lefts" >
                    {{-- <p>Photo</p> --}}
                </div>
                <div class="rights">
                    <img src="{{Storage::url($data->image)}}" alt="">
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Photo</p>
                </div>
                <div class="rights image">
                    <input type="file" name="image" id="image">
                    @if ($errors->has('image'))
                    <div class="errors">
                        <span class="text-danger">{{$errors->first('image')}}</span>
                    </div>
                    @endif
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Price</p>
                </div>
                <div class="rights">
                    <input type="text" name="price" value="{{$data->price}}"id="price">
                    @if ($errors->has('price'))
                    <div class="errors">
                        <span class="text-danger">{{$errors->first('price')}}</span>
                    </div>
                    @endif
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Stock</p>
                </div>
                <div class="rights">
                    <input type="number" name="stock"value="{{$data->stock}}" id="stock">
                    @if ($errors->has('stock'))
                    <div class="errors">
                        <span class="text-danger">{{$errors->first('stock')}}</span>
                    </div>
                    @endif
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Description</p>
                </div>
                <div class="rights">
                    <textarea name="description" id="description" rows="15">{{$data->description}}</textarea>
                    @if ($errors->has('description'))
                    <div class="errors">
                        <span class="text-danger">{{$errors->first('description')}}</span>
                    </div>
                    @endif
                </div>
            </div>
            <div class="buttons-container-add">
                <button type="submit">Save</button>
                <a href="/add">Cancel</a>
            </div>

        </form>
    </div>
    <script>
        var at =  document.getElementById("name");
    </script>
    {{View::make('layout.footer')}}
</body>
</html>
