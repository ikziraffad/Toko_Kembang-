<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/add.css">
    <link rel="stylesheet" href="/css/login.css">
    <title>TOKEM | Add Product</title>
</head>

<body>
    {{View::make('layout.header')}}
    @php
    $category = App\Models\categories::all();
    @endphp
    <div class="contents-container">
        <h1>Add Product</h1>
        <form action="/add/product/" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="inputs-container">
                <div class="lefts">
                    <p>Photo</p>
                </div>
                <div class="rights image">
                    <input type="file" name="image" id="image">
                    @if ($errors->has('image'))
                    <div class="errors">
                        <span class="text-danger">{{$errors->first('image')}}</span>
                    </div>
                    @endif
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Name</p>
                </div>
                <div class="rights">
                    <input type="text" value="{{old('name')}}" name="name" id="name">
                    @if ($errors->has('name'))
                    <div class="errors">
                        <span class="text-danger">{{$errors->first('name')}}</span>
                    </div>
                    @endif
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Price</p>
                </div>
                <div class="rights">
                    <input type="text" name="price" value="{{old('price')}}"id="price">
                    @if ($errors->has('price'))
                    <div class="errors">
                        <span class="text-danger">{{$errors->first('price')}}</span>
                    </div>
                    @endif
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Stock</p>
                </div>
                <div class="rights">
                    <input type="number" name="stock"value="{{old('stock')}}" id="stock">
                    @if ($errors->has('stock'))
                    <div class="errors">
                        <span class="text-danger">{{$errors->first('stock')}}</span>
                    </div>
                    @endif
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Description</p>
                </div>
                <div class="rights">
                    <textarea name="description" id="description" rows="15">{{old('description')}}</textarea>
                    @if ($errors->has('description'))
                    <div class="errors">
                        <span class="text-danger">{{$errors->first('description')}}</span>
                    </div>
                    @endif
                </div>
            </div>
            <div class="inputs-container">
                <div class="lefts">
                    <p>Category</p>
                </div>
                <div class="rights">

                    <select name="category" id="category">
                        <option value="">Choose a Category</option>
                        @foreach ($category as $item)
                        <option {{ old('category') == $item->name ? "selected" : "" }} value="{{$item->name}}">
                            {{$item->name}}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('category'))
                    <div class="errors">
                        <span class="text-danger">{{$errors->first('category')}}</span>
                    </div>
                    @endif
                </div>
            </div>
            <div class="buttons-container-add">
                <button type="submit">Save</button>
                <a href="/add">Cancel</a>
            </div>

        </form>
    </div>
    <script>
        var at =  document.getElementById("name");
    </script>
    {{View::make('layout.footer')}}
</body>

</html>
