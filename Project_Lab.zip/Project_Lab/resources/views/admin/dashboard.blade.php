<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/dash.css">
    <title>TOKEM | Admin</title>
</head>
<body>
    {{View::make('layout.header')}}

    <div class="contents-container">
        <h1>Choose an Option</h1>
        <a href="/add/category/admin">
            <div class="buttons-container">
                <img src="{{Storage::url('Image/category.png')}}" alt="">
                <p>
                    Add Category
                </p>
            </div>
        </a>
        <a href="/add/product/admin">
            <div class="buttons-container">
                <img src="{{Storage::url('Image/distributed.png')}}" alt="">
                <p>
                    Add Product
                </p>
            </div>
        </a>

    </div>

    {{View::make('layout.footer')}}
</body>
</html>

