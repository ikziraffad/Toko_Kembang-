<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/cart.css">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TOKEM | Cart Confirmation</title>
    <link rel="stylesheet" href="/css/login.css">
</head>
<body>
    {{View::make('layout.header')}}
    @php
        $total = 0;
    @endphp
    <div class="contents-container">

        <h1>Please Confirm Your Order</h1>
        <div class="carts-box">
            <div class="tops">
                <div class="prod">
                    <p>PRODUCT</p>
                </div>
                <div class="price">
                    <p>PRICE</p>
                </div>
                <div class="qty">
                    <p>QUANTITY</p>
                </div>
                <div class="subtotal">
                    <p>SUBTOTAL</p>
                </div>
            </div>
            @foreach ($data as $item)
            <div class="bottoms">
                <div class="prod">
                    <img src="{{Storage::url($item->product[0]->image)}}" alt="">
                    <p>{{$item->product[0]->name}}</p>
                </div>
                <div class="price">
                    <p>Rp. {{$item->product[0]->price}},00</p>
                </div>
                <div class="qty">
                    <div class="inputs">
                        <p>{{$item->quantity}}</p>
                    </div>
                </div>
                <div class="subtotal">
                    <p>Rp. {{$item->quantity * $item->product[0]->price}},00</p>
                    @php
                        $total = $total + ($item->quantity * $item->product[0]->price);
                    @endphp
                </div>
            </div>
            @endforeach
        </div>
        <h3 style="padding-top: 20px;">Ships to : {{$data[0]->user->address}}</h3>
        <div class="totals">
            @php
                $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                $charactersLength = strlen($characters);
                $randomString = '';
                for ($i = 0; $i < 6; $i++) {
                    $randomString .= $characters[rand(0, $charactersLength - 1)];
                }
            @endphp
            <h2>Grand Total : Rp. {{$total}},00</h2>
            <form action="/cart/confirmation/submit">
                <p style="font-size: 19px;">Please Enter The Following Passcode to Checkout {{$randomString}}</p>
                <input type="hidden" name="conf" value="{{$randomString}}">
                <input type="text" name="pass" id="pass" placeholder="XXXXXX">
                @if ($errors->any())
                <div class="errors">
                    <span class="text-danger">{{$errors->first() }}</span>
                </div>
                @endif
                <button type="submit" style="cursor: pointer; border-style: none;">Checkout</button>
            </form>
        </div>
    </div>
    {{View::make('layout.footer')}}
</body>
</html>
