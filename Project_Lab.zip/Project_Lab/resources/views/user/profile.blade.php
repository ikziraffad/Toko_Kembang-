<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/home.css">
    <link rel="stylesheet" href="/css/profile.css">
    <title>TOKEM | Account</title>
</head>
<body>
    {{View::make('layout.header')}}
    <div class="heads"></div>

    <div class="contents-1-container profile">
        <div class="contents-1-atas">
            <h1 class="bawah">My Account</h1>
        </div>
    </div>

    <div class="contents-2-container">
        <div class="contents-2-box">
            <div class="profile-container">
                <legend>Name</legend>
                <p>{{$data->name}}</p>
            </div>
            <div class="profile-container">
                <legend>Email</legend>
                <p>{{$data->email}}</p>
            </div>
            <div class="profile-container">
                <legend>Phone Number</legend>
                <p>{{$data->phone}}</p>
            </div>
            <div class="profile-container">
                <legend>Address</legend>
                <p>{{$data->address}}</p>
            </div>
            <div class="buttons-container profile">
                @if (Auth::check())
                <a href="/account/update">Update Profile</a>
                @if (Auth::user()->role=="user")
                <a href="/user/history">Transaction History</a>
                @endif
                @endif
            </div>
        </div>
    </div>

    {{View::make('layout.footer')}}
</body>
</html>

