<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/cart.css">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TOKEM | History Transaction</title>
    <link rel="stylesheet" href="/css/login.css">
</head>

<body>
    {{View::make('layout.header')}}

    <div class="contents-container">
        @if ($data->isEmpty())
        <h1>Your Don't Have Any Transaction</h1>
        @else
        <h1>Transaction History</h1>
        @foreach ($data as $item)
        <h2>Transaction Date : {{$item->created_at}}</h2>
        <div class="carts-box history">
            <div class="tops">
                <div class="prod">
                    <p>PRODUCT</p>
                </div>
                <div class="price">
                    <p>PRICE</p>
                </div>
                <div class="qty">
                    <p>QUANTITY</p>
                </div>
                <div class="subtotal">
                    <p>SUBTOTAL</p>
                </div>
            </div>
            @foreach ($item->detail as $key)
            <div class="bottoms">
                <div class="prod">
                    <img src="{{Storage::url($key->product[0]->image)}}" alt="">
                    <p>{{$key->product[0]->name}}</p>
                </div>
                <div class="price">
                    <p>Rp. {{$key->product[0]->price}},00</p>
                </div>
                <div class="qty">
                    <p></p>
                </div>
                <div class="subtotal">
                    <p>Rp. {{$key->quantity * $key->product[0]->price}},00</p>
                </div>
            </div>
            @endforeach
        </div>
        @endforeach

        @endif
    </div>


    {{View::make('layout.footer')}}
</body>

</html>
