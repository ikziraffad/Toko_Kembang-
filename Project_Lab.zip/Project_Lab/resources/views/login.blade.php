<!DOCTYPE html>
<html lang="en" style="background-image:url({{Storage::url('Image/bg-login-regis.jpg')}});">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/login.css">
    <title>TOKEM | Login</title>
</head>
<body>
    <div class="container">
        <div class="cont-1">
            <img src="{{Storage::url('Image/logo.svg')}}" alt="">
            <a href="/register">Don't Have an Account?</a>
        </div>

        <form method="POST" action="{{route('login-user')}}">
            @csrf
            @php
                if(isset($_COOKIE['email'])&&isset($_COOKIE['password'])){
                    $email = $_COOKIE['email'];
                    $password = $_COOKIE['password'];
                    $remembered = "checked='checked'";
                }else{
                    $email = '';
                    $password = '';
                    $remembered ="";
                }
            @endphp
            @if ($errors->has('credential'))
            <div class="errors">
                <span class="text-danger">{{ $errors->first('credential') }}</span>
            </div>
            @endif
            <div class="input-container">
                <p>Email</p>
                <input type="email" value="{{$email}}"name="email" id="email" placeholder="user@user.com">
                @if ($errors->has('email'))
                <div class="errors">
                    <span class="text-danger">{{ $errors->first('email') }}</span>
                </div>
                @endif
            </div>
            <div class="input-container">
                <p>Password</p>
                <input type="password" name="password" value="{{$password}}"id="password" placeholder="Password">
                @if ($errors->has('Password'))
                <div class="errors">
                    <span class="text-danger">{{ $errors->first('password') }}</span>
                </div>
                @endif
            </div>
            <div class="input-container remember">
                <input type="checkbox" name="remember" {{$remembered}} id="remember">
                <p>Remember me</p>
            </div>

            <button>
                <input class="login-btn"type="submit" value="Log In" placeholder="login">
            </button>

        </form>
    </div>
</body>
</html>
