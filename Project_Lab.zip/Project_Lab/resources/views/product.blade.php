<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/product.css">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <title>TOKEM | Product</title>
</head>

<body>
    {{View::make('layout.header')}}

    <div class="contents-container">
        <div class="container-produk">
            <div class="top-part d-flex justify-content-between align-items-center">
                <h1>Our Product</h1>
                <form action="/product/search">
                    <input type="text" name="search" id="search">
                    <button type="submit">Search</button>
                </form>
            </div>
            <div class="bottom-part container mx-auto mt-5">
                <div class="row">
                    @if (!$data->isEmpty())
                    @foreach ($data as $item)


                    @if (Auth::check())
                        @if(Auth::user()->role=='user' && $item->stock==0)
                        @else
                        <div class="col-md-3 mb-3">
                            <div class="card" style="width: 18rem;">
                                <a href="/product/{{$item->id}}">
                                    <img src="{{Storage::url($item->image)}}" class="card-img-top" alt="image product">
                                </a>
                                <div class="card-body">
                                    <a href="/product/{{$item->id}}" class="card-title text-dark">{{$item->name}}</a>
                                    <h6 class="card-subtitle mb-2 text-muted">Rp. {{$item->price}},00</h6>
                                    <p class="card-text"></p>
                                    @guest
                                    <a href="/product/{{$item->id}}" class="btn mr-2 text-white">Add to Cart</a>
                                    @else
                                    @if (Auth::user()->role=="user")
                                    <a href="/product/{{$item->id}}" class="btn mr-2 text-white">Add to Cart</a>
                                    @else
                                    @if ($item->stock==0)
                                    <p class="text-danger">Product Unavailable</p>
                                    @endif
                                    <a href="/edit/{{$item->name}}/admin" class="btn mr-2 text-white"><i
                                            class="bi bi-pencil"></i> Edit</a>
                                    <a href="/delete/product/{{$item->id}}" class="btn mr-2 text-white"><i
                                            class="bi bi-trash"></i> Remove</a>
                                    @endif
                                    @endguest
                                </div>
                            </div>
                        </div>
                        @endif
                    @elseif ($item->stock!=0)
                    <div class="col-md-3 mb-3">
                        <div class="card" style="width: 18rem;">
                            <a href="/product/{{$item->id}}">
                                <img src="{{Storage::url($item->image)}}" class="card-img-top" alt="image product">
                            </a>
                            <div class="card-body">
                                <a href="/product/{{$item->id}}" class="card-title text-dark">{{$item->name}}</a>
                                <h6 class="card-subtitle mb-2 text-muted">Rp. {{$item->price}},00</h6>
                                <p class="card-text"></p>
                                <a href="/product/{{$item->id}}" class="btn mr-2 text-white">Add to Cart</a>
                            </div>
                        </div>
                    </div>
                    @endif



                    @endforeach
                    @else
                    <h1>No Product Match</h1>
                    @endif



                </div>
            </div>

        </div>
        <div class="links d-flex justify-content-center mt-3">
            {{$data->links()}}
        </div>
    </div>
    {{View::make('layout.footer')}}
</body>

</html>
