<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/home.css">
    <title>TOKEM | Home</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
</head>

<body>

    {{View::make('layout.header')}}
    <div class="heads"></div>
    @if(Session::has('stat'))
    <script type='text/javascript'>
        alert("Transaction success! You will receive our products soon! thank you for shopping with us!");
    </script>
    @php
        Session::forget('stat');
    @endphp
    @endif
    <div class="contents-1-container">
        <div class="contents-1-atas">
            <h1 class="atas">Level Up Your</h1>
            <h1 class="bawah">Planting Game</h1>
        </div>
        <div class="contents-1-bawah">
            <img class="img-home" src="{{Storage::url('Image/bg-home.jpg')}}" alt="">
            <div class="contents-1-bawah-atas"></div>
            <div class="contents-1-bawah-bawah"></div>
        </div>
    </div>
    <div class="contents-2-container">
        <div class="judul">
            <h2>One-stop boutique for all your home and office gardening needs</h2>
            <p>We provide wide variety of plants and gardening service</p>
        </div>

        <div class="contents-2-tengah">
            <div class="contents-2-tengah-kiri">
                <h2>Be a plant parent now!</h2>
                <p>Beautify your surrondings by adding a touch of live plant. We provide any plant to step in becoming
                    plant parent.</p>
            </div>
            <div class="contents-2-tengah-kanan">
                <img src="{{Storage::url('Image/pic-home1.jpeg')}}" alt="">
            </div>
        </div>

        <div class="contents-2-tengah">
            <div class="contents-2-tengah-kanan">
                <img src="{{Storage::url('Image/pic-home2.jpg')}}" alt="">
            </div>
            <div class="contents-2-tengah-kiri bawah">
                <h2>Professional plant care</h2>
                <p>Make a great working environment by having plants around to provide fresh air and joyous feelings. We will take care for everything in your office from installation to maintenance.</p>
            </div>
        </div>

    </div>





    {{View::make('layout.footer')}}
</body>

</html>
