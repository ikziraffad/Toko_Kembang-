<link rel="stylesheet" href="/css/main.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
<nav class="navigation-bars">
    <div class="nav-lefts">
        <a class="logo" href="#">
            <img src="{{Storage::url('Image/logo.svg')}}" alt="logo">
        </a>
    </div>

    <div class="nav-rights">
        <li class="navlist-items">
            <a href="/" class="item {{ (request()->is('/'))||(request()->is('home')) ? 'active' : '' }}">Home</a>
        </li>
        <li class="navlist-items">
            <a href="/product" class="item {{ (request()->is('product')) ? 'active' : '' }}">Product</a>
        </li>
        <li class="navlist-items">
            <a href="/aboutus" class="item {{ (request()->is('aboutus')) ? 'active' : '' }}">About Us</a>
        </li>

        @guest
        <li class="navlist-items">
            <a href="/login" class="item">Login</a>
        </li>
        @else
        @if (Auth::user()->role=='admin')
        <li class="navlist-items">
            <a href="/add" class="item {{ (request()->is('add')) ? 'active' : '' }}">Admin Dashboard</a>
        </li>

        @else
        <li class="navlist-items">
            <a href="/cart" class="item {{ (request()->is('cart')) ? 'active' : '' }}">Cart</a>
        </li>

        @endif
        <li class="navlist-items">
            <a href="/account" class="item {{ (request()->is('account')) ? 'active' : '' }}">Account</a>
        </li>
        <li class="navlist-items">
            <a href="{{route('logout-user')}}" class="item">Logout</a>
        </li>
        @endguest
    </div>
</nav>
