<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/aboutUs.css">

    <title>TOKEM | About Us</title>
  </head>
  <body>
    {{View::make('layout.header')}}

    <div class="container-fluid">
        <div class="row align-items-start d-flex align-items-center" style="height: 700px">
            <div class="col text-center d-flex flex-column align-items-center justify-content-center" style="height: 400px;">
                <h1>"Toko Kembang grew from our love for flower and to spread the love in our community, we started off from street vendor near Rawa Belong Street and now we habe the most diverse collection for plants and we provide proffesional insatallation and ongoing maintenance of your live plants"</h1>
                <div class="d-flex justify-content-center align-items-center" style="height:fit-content">
                    <p class="bold">Nanda ria /</p>
                    <p class="font-weight-normal">CEO, Tokem</p>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="row d-flex justify-content-around" style="height:600px; border-bottom: 2px solid rgba(88, 88, 88, 0.699);">
                <div class="col-sm-2">
                    <h1>Get in Touch</h1>
                </div>
                <div class="col-lg-6 d-flex">
                    <div class="col-lg-3" style="width:50%">
                        <div class="col" style="height:50%">
                            <h4>Sales Inquiry</h4>
                            <p height="1%">sales@tokem.com</p>
                            <p height="1%">+62 (021) 8440-7279 ext 1</p>
                        </div>
                        <div class="col" style="height:50%">
                            <h4>B2B</h4>
                            <p height="1%">b2b@tokem.com</p>
                            <p height="1%">+62 (021) 8440-7279 ext 6</p>

                        </div>
                    </div>
                    <div class="col-lg-3"style="width:50%">
                        <h4>Customer Service</h4>
                        <p height="1%">cs@tokem.com</p>
                        <p height="1%">+62 (021) 8440-7279 ext 9</p>

                    </div>
                </div>
            </div>
            <div class="row d-flex justify-content-around" style="height:600px; padding-top:100px;">
                <div class="col-sm-2">
                    <h1>Locations</h1>
                </div>
                <div class="col-lg-6 d-flex">
                    <div class="col-lg-3" style="width:50%">
                        <div class="col" style="height:50%">
                            <h4>Jakarta</h4>
                            <p height="1%">Jl. Rawa Belong No. 420<br>11420</p>

                        </div>
                        <div class="col" style="height:50%">
                            <h4>Karawang</h4>
                            <p height="1%">Jl. Belakang Pasar No.14<br>41311</p>
                        </div>
                    </div>
                    <div class="col-lg-3"style="width:50%">
                        <div class="col" style="height:50%">
                            <h4>Bandung</h4>
                            <p height="1%">Jl. Dr. Setiabudi No.269<br>40154</p>
                        </div>
                        <div class="col" style="height:50%">
                            <h4>Surabaya</h4>
                            <p height="1%">Jl. Ngagel No.173<br>60246</p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        {{-- <img src="{{Storage::url('Image/bg-home.jpg')}}" alt=""> --}}
    </div>

    {{View::make('layout.footer')}}
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>
