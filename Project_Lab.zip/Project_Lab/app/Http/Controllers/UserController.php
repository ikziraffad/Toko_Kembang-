<?php

namespace App\Http\Controllers;

use App\Models\carts;
use App\Models\header_transaction;
use App\Models\products;
use App\Models\transaction_detail;
use App\Models\User;
use App\Rules\CheckPassword;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class UserController extends Controller
{
    public function registration(Request $req){
        $req->validate([
            'Name' => 'required',
            'Email' => 'required|email|unique:users,email',
            'Address' => 'required|min:15',
            'Phone' => 'required|numeric|min:11',
            'Password' => 'required|min:8|required_with:Confirmation|same:Confirmation',
        ]);
        $user = new User();
        $user->name = $req->Name;
        $user->email = $req->Email;
        $user->address = $req->Address;
        $user->phone = $req->Phone;
        $user->password = Hash::make($req->Password);
        $user->save();
        return redirect('/login');
    }
    public function login(Request $req){
        $req->validate([
            'email'=>'required',
            'password'=>'required',
        ]);
        $creds = $req->only('email', 'password');
        $user = User::where(['email'=>$req->email])->first();

        if(Auth::attempt($creds)){
            if($req->remember==null){

            }
            else{
                setcookie('email', $req->email, time()+( 5 * 365 * 24 * 60 * 60));
                setcookie('password', $req->password, time()+( 5 * 365 * 24 * 60 * 60));
            }
            $req->session()->put('user', $user);
            Auth::login($user);
            return redirect('/');
        }
        return back()->withErrors([
            'credential' => "Email or Password Doesn't Match",
        ]);

    }
    public function logout(){
        Session::flush();
        Session::forget('user');
        Auth::logout();
        return redirect('/');
    }

    public function getProfile(){
        $data = User::find(Auth::user()->id);
        return view('user.profile', compact('data'));
    }

    public function getProfielUpdates(){
        $data = User::find(Auth::user()->id);
        return view('updateProfile', compact('data'));
    }
    public function updateProfile(Request $request){
        $request->validate([
            'name' => 'required',
            'address' => 'required|min:15',
            'phone' => 'required|numeric|min:11',
            'password' => ['required','min:8', new CheckPassword],
        ]);
        if($request->new_password!=null){
            $request->validate([
                'new_password' => 'required|required_with:confirmation_password|same:confirmation_password',
                'confirmation_password' => 'required'
            ]);
        }
        $user = User::find(Auth::user()->id);
        $user->name = $request->name !=null ? $request->name : $user->name;
        $user->address = $request->address !=null ? $request->address : $user->address;
        $user->phone = $request->phone !=null ? $request->phone : $user->phone;
        $user->password = $request->new_password !=null ? Hash::make($request->new_password) : $user->password;
        $user->save();
        return redirect('/account');
    }
    public function getProduct(){
        $data = products::paginate(8);
        // return $data;
        return view('product', ['data' => $data]);
    }
    public function addToCart(Request $request){
        $request->validate([
            'quantity'=>'required',
        ]);
        $product = products::find($request->product_id);
        $cart_data = carts::where('user_id', Auth::user()->id)->get();
        foreach ($cart_data as $item) {
            if($item->product_id == $request->product_id){
                return redirect()->back()->withErrors('Item Already in Cart');
            }
        }

        $cart = new carts();
        $cart->user_id = Auth::user()->id;
        $cart->product_id = $request->product_id;
        $cart->quantity = $request->quantity;
        $cart->save();

        return redirect('/product');
    }

    public function getCart(){
        $data = carts::where('user_id', Auth::user()->id)->get();
        return view('user.cart', ['data'=>$data]);
    }
    public function getCartConf(){
        $data = carts::where('user_id', Auth::user()->id)->get();
        return view('user.cartConfirm', ['data'=>$data]);
    }
    public function updateCart(Request $request){
        $data = carts::where('user_id', Auth::user()->id)->get();
        foreach ($data as $item) {
            if($item->product_id == $request->product_id){
                if($request->quantity!=0&&$request->quantity<=$item->product[0]->stock){
                    $item->quantity = $request->quantity;
                    $item->save();
                    return redirect()->back();
                }
                else if($request->quantity==0){
                    $item->delete();
                    return redirect()->back();
                }
                else if($request->quantity>$item->product[0]->stock){
                    return redirect()->back()->withErrors($item->product[0]->name.' stock Does Not Meet The Requirement');
                }

            }
        }
    }

    public function confirmPasscode(Request $request){
        if($request->conf!=$request->pass){
            return redirect()->back()->withErrors("Passcode Doesn't Match");
        }
        else{
            $id = Auth::user()->id;
            $cart = carts::where('user_id', $id)->get();
            // dd($cart);
            $total = 0;
            foreach ($cart as $item) {
                $total = $total + ($item->quantity * $item->product[0]->price);
            }
            $header = new header_transaction();
            $header->user_id = $id;
            $header->totalPrice = $total;
            $header->save();
            foreach ($cart as $item){
                $detail = new transaction_detail();
                $detail->transaction_id = $header->id;
                $detail->product_id = $item->product_id;
                $detail->quantity = $item->quantity;
                $detail->subtotal = $item->quantity * $item->product[0]->price;
                $stock = $item->product[0]->stock - $item->quantity;
                $prod = products::find($item->product_id);
                $prod->stock = $stock;
                $prod->save();
                $detail->save();
            }
            $cart->each->delete();
            $request->session()->put('stat', 'Success');
            return redirect('/')->with('status', 'Success');
        }
    }
    public function getHistory(){
        $data = header_transaction::where('user_id', Auth::user()->id)->get();
        // return $data;
        return view('user.history', ['data' => $data]);

    }
}
