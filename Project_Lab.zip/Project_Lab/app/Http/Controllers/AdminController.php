<?php

namespace App\Http\Controllers;

use App\Models\categories;
use App\Models\products;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class AdminController extends Controller
{
    public function index(){
        if(Auth::check()){
            if(Auth::user()->role == 'admin'){
                return view('admin.dashboard');
            }
            else{
                return redirect('/');
            }
        }
        return redirect('/login');
    }

    public function getAdd($page){
        if(Auth::check()){
            if(Auth::user()->role == 'admin'){
                return view('admin.'.$page);
            }
            else{
                return redirect('/');
            }
        }
        return redirect('/login');
    }

    public function addProduct(Request $request){
        $request->validate([
            'image' => 'required|mimes:png,jpg,jpeg',
            'name' => 'required|min:5',
            'price' => 'required|integer|gte:1000|lte:10000000',
            'stock'=>'required|gte:1|lte:10000',
            'description' => 'required|min:15|max:500',
            'category' => 'required',
        ]);
        $product = new products();
        $cat = categories::where('name', $request->category)->get();
        // dd($cat[0]->id);

        $file_image = $request->file('image');
        $image_name = time().'.'.$file_image->getClientOriginalExtension();
        Storage::putFileAs('public/Image', $file_image, $image_name);
        $image_name = 'Image/'.$image_name;

        $product->name = $request->name;
        $product->price = $request->price;
        $product->stock = $request->stock;
        $product->description = $request->description;
        $product->category_id = $cat[0]->id;
        $product->image = $image_name;

        $product->save();

        return redirect('/add');
    }

    public function addCategory(Request $request){
        $request->validate([
            'category'=> 'required|alpha|unique:categories,name',
        ]);
        $category = new categories();
        $category->name = $request->category;
        $category->save();

        return redirect('/add');
    }

    public function deleteProduct($id){
        if(Auth::user()->role == 'user'){
            return redirect('/');
        }
        $data = products::find($id);
        Storage::delete('public/'.$data->image);
        $data->delete();
        return redirect()->back();
    }

    public function getEditProduct($name){
        $data = products::where('name', $name)->get();
        // dd($data);
        return view('admin.edit', ['data' => $data[0]]);
    }
    public function editProduct(Request $request, $id){
        if(Auth::check()){
            if(Auth::user()->role == 'user'){
                return redirect('/');
            }
            $request->validate([
                'image' => 'mimes:png,jpg,jpeg',
                'price' => 'integer|gte:1000|lte:10000000',
                'stock'=>'gte:1|lte:10000',
                'description' => 'min:15|max:500',
            ]);

            $product = products::find($id);
            $img = $request->file('image');
            if($img!=null){
                $image_name = time().'.'.$img->getClientOriginalExtension();
                Storage::putFileAs('public/Image', $img, $image_name);
                $image_name = 'Images/'.$image_name;

                Storage::delete('public/'.$product->image);
            }
            else{
                $image_name = $product->image;
            }
            $product->price = $request->price!=null ? $request->price : $product->price;

            $product->stock = $request->stock!=null ? $request->stock : $product->stock;

            $product->description = $request->description!=null ? $request->description : $product->description;

            $product->image = $image_name;
            // dd($product);
            $product->save();
            return redirect('/product');
        }
        else{
            return redirect('/login');
        }
    }

}
