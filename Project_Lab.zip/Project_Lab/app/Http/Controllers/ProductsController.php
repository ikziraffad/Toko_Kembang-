<?php

namespace App\Http\Controllers;

use App\Models\products;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProductsController extends Controller
{
    public function search(Request $request){
        $data = products::where('name','LIKE', "%$request->search%")->paginate(8);
        // dd($request);
        return view('product', ['data'=>$data]);
    }
    public function getDetail($id){
        $data = products::find($id);
        if(Auth::check()){
            return view('detail', ['data'=>$data]);
        }
        return redirect('/login');
    }
}
