<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class products extends Model
{
    use HasFactory;
    public function category(){
        return $this->belongsTo(categories::class, "category_id", "id");
    }
    public function cart(){
        return $this->belongsTo(carts::class, "product_id", "id");
    }
    public function detail(){
        return $this->belongsTo(transaction_detail::class, "product_id", "id");
    }
}
