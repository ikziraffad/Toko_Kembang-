<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('products')->insert([
            [
                'category_id' => 2,
                'name' => 'Aloe Polyphylla',
                'description' => "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Animi, ea voluptatem fugit, eum ducimus possimus assumenda quis aut corporis saepe debitis veritatis expedita dolores omnis. Aperiam atque similique sunt molestiae.",
                'price' => 180000,
                'stock'=> 6,
                'image' => 'Image/polyphylla.jpeg',
            ],
            [
                'category_id' => 2,
                'name' => 'Aeonium Canariense',
                'description' => "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ipsum laudantium odio, quos doloribus eveniet sequi itaque soluta delectus recusandae dolorum ea quae perspiciatis porro nostrum, qui, quam debitis laboriosam adipisci?",
                'price'=>100000,
                'stock'=>20,
                'image' => 'Image/canariense.jpeg',
            ],

            [
                'category_id' => 4,
                'name' => 'Heartleaf Philodendron',
                'description' => "If you are a novice gardener, this one is for you, as it's forgiving in nature. It's one of the most popular philodendrons with signature heart-shaped leaves. It can reach a length of around 4-6 feet indoors, and allowed to grow freely.",
                'price' => 96000,
                'stock' => 56,
                'image' => 'Image/Heartleaf-philodendron.jpg.webp',
            ],
            [
                'category_id' => 4,
                'name' => 'Philodendron Moonlight',
                'description' => "This hybrid plant, the Philodendron Moonlight, is a non-vining, clump-forming plant that has bright, lime-green leaves. The fluorescent green foliage can brighten up any shaded corner of a room. New leaves grow as sunny-yellow leaves that gradually darken as they age. However, compared to other varieties of Philodendron, this cultivar is a bright-looking plant.",
                'price' => 290000,
                'stock' => 8,
                'image' => 'Image/Moonlight-Philodendron.jpg',
            ],
            [
                'category_id' => 4,
                'name' => 'Split Leaf Philodendron',
                'description' => "Want people to take notice of your philodendron? Though it's not from the philodendron genus, we've included it in our list thanks to its beautiful look, It can achieve a towering height of 5-6 feet while growing indoors. It has stunning cut foliage and can be grown as a wine indoors very easily.",
                'price'=> 300000,
                'stock' => 2,
                'image' => 'Image/Split-Leaf-Philodendron.jpg.webp',
            ],
            [
                'category_id' => 4,
                'name' => 'Winterbourn Philodendron',
                'description' => "Growing up to 3-4 feet in width and height, its leaves are ruffled at the edges, with a dark green hue. It grows upright in the absence of aerial roots, looking excellent indoors. The dense clumps and lobed leaves are surely going to attract onlookers.",
                'price'=> 285000,
                'stock' => 9,
                'image' => 'Image/Winterbourn-Philodendron.jpg.webp',
            ],
            [
                'category_id' => 4,
                'name' => 'White Knight Philodendron',
                'description' => "This is the prized possession among the philodendron collectors, as it's rare and beautiful! It grows slowly, but the wait is worth it! Its stems have a unique purple-brown and cream color with white splotches on the dark green leaves.",
                'price'=> 375000,
                'stock' => 32,
                'image' => 'Image/Philodendron-White-Knight.jpg.webp',
            ],
        ]);
    }
}
